﻿using System;

namespace CursoFoop_Solid_Exercicio2
{
    class Program
    {
        static void Main(string[] args)
        {
           
            Console.ReadLine();
        }
    }
}
